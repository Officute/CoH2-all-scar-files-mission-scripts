--? @group scardoc;Encounter

import("Systems/AiManager/Goals/BaseGoal.scar")

Ai = Ai or fatal("Ai not loaded properly")
Ai.goals = Ai.goals or {}
Ai.goals.AbilityGoal = Clone(Ai.goals.BaseGoal)
Ai.goals.DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData or {} -- preserve data on soft-reload

local AbilityGoal = Ai.goals.AbilityGoal

AbilityGoal._BaseCreate = AbilityGoal.Create
AbilityGoal._BaseSetupSkirmishAI = AbilityGoal.SetupSkirmishAI
AbilityGoal._BaseUpdateGoalData = AbilityGoal.UpdateGoalData


function AbilityGoal:Create(encounter, goalData, defaultGoalData, overrideGoalData, modifyGoalData)
	local DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData
	defaultGoalData = defaultGoalData or DefaultAbilityGoalData.defaultGoalData
	overrideGoalData = overrideGoalData or DefaultAbilityGoalData.overrideGoalData
	modifyGoalData = modifyGoalData or DefaultAbilityGoalData.modifyGoalData
	
	local goal = self:_BaseCreate(encounter, goalData, defaultGoalData, overrideGoalData, modifyGoalData)
	
	if(not goal.data.target) then fatal("ERROR: No ability target defined for encounter "  .. encounter.data.name) end
	if(not goal.data.abilityParams) then fatal("ERROR: No ability params defined for encounter "  .. encounter.data.name) end
	if(goal.objective) then fatal("ERROR: Objective object already defined for encounter "  .. encounter.data.name) end
	
	goal:CreateSkirmishAI()
	
	return goal
end

function AbilityGoal:UpdateGoalData(goalData, defaultGoalData, overrideGoalData, modifyGoalData)
	local DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData
	defaultGoalData = defaultGoalData or DefaultAbilityGoalData.defaultGoalData
	overrideGoalData = overrideGoalData or DefaultAbilityGoalData.overrideGoalData
	modifyGoalData = modifyGoalData or DefaultAbilityGoalData.modifyGoalData

	self:_BaseUpdateGoalData(goalData, defaultGoalData, overrideGoalData, modifyGoalData)
end

--Create and Setup ability based on skirmish AI
function AbilityGoal:CreateSkirmishAI()
	if (not AI_IsEnabled(self.encounter.data.player)) then
		Ai:Print("Skipping Skirmish AI - player not enabled AI")
		self.objective = nil
		return
	end
	
	Ai:Print("Creating AI Objective...")
	self.objective = AI_CreateObjective(self.encounter.data.player, AIObjectiveType_Ability)
	
	self:SetupEncounterSkirmishAI()
	self:SetupSkirmishAI()
end

--Setup ability based on skirmish AI
function AbilityGoal:SetupSkirmishAI()
	if (self.objective == nil or not AIObjective_IsValid(self.objective)) then
		self.objective = nil
		return
	end
	
	Ai:Print("Setting up Skirmish AI")
	
	self:_BaseSetupSkirmishAI()

	if (self.data.maxIdleTime) then
		AIObjective_EngagementGuidance_SetMaxIdleTime(self.objective, self.data.maxIdleTime)
	end
	
	if (self.data.abilityParams) then
		AIAbilityObjective_AbilityGuidance_SetAbilityPBG(self.objective, self.data.abilityParams.abilityPBG) 
	end
end


--[[
-- Ability Goal Data Interface
]]--

--? @shortdesc Adjust default goal data for ability goals.  Sets the default GoalData to the current defaults plus additionalDefaultGoalData; any values specified are used for unspecified encounter ability goal values.
--? @args Table additionalDefaultGoalData
function AIAbilityGoal_AdjustDefaultGoalData(additionalDefaultGoalData)
	Ai:Print("===============================================")
	Ai:Print("Adjusting AbilityGoal default data...")

	local additionalGoalData = Clone(additionalDefaultGoalData)
	_AIDefaultGoalData_SetDefaultGoalDataMetaData(additionalGoalData)
	local DefaultBaseGoalData = Ai.goals.DefaultGoalData
	local DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData
	local defaultGoalData = DefaultAbilityGoalData.defaultGoalData or DefaultBaseGoalData.defaultGoalData
	DefaultAbilityGoalData.defaultGoalData = MergeCloneTable(defaultGoalData, additionalGoalData)

	Ai:Print("-----------------------------------------------")
	Ai:Print("additionalDefaultGoalData")
	Ai:Print(additionalGoalData)
	Ai:Print("-----------------------------------------------")
	DebugPrintGoals(DefaultAbilityGoalData.defaultGoalData, DefaultAbilityGoalData.overrideGoalData, DefaultAbilityGoalData.modifyGoalData)
	Ai:Print("===============================================")
end

--? @shortdesc Set default goal data for ability goals.  defaultGoalData is cloned; any values specified are used for unspecified encounter ability goal values.
--? @args Table defaultGoalData
function AIAbilityGoal_SetDefaultGoalData(defaultGoalData)
	Ai:Print("===============================================")
	Ai:Print("Setting AbilityGoal default data...")

	local DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData
	DefaultAbilityGoalData.defaultGoalData = Clone(defaultGoalData)
	_AIDefaultGoalData_SetDefaultGoalDataMetaData(DefaultAbilityGoalData.defaultGoalData)

	DebugPrintGoals(DefaultAbilityGoalData.defaultGoalData, DefaultAbilityGoalData.overrideGoalData, DefaultAbilityGoalData.modifyGoalData)
	Ai:Print("===============================================")
end

--? @shortdesc Set override goal data for ability goals.  overrideGoalData is cloned; any values specified are used for encounter ability goal values.
--? @args Table overrideGoalData
function AIAbilityGoal_SetOverrideGoalData(overrideGoalData)
	Ai:Print("===============================================")
	Ai:Print("Setting AbilityGoal override data...")

	local DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData
	DefaultAbilityGoalData.overrideGoalData = Clone(overrideGoalData)
	_AIDefaultGoalData_SetDefaultGoalDataMetaData(DefaultAbilityGoalData.overrideGoalData)

	DebugPrintGoals(DefaultAbilityGoalData.defaultGoalData, DefaultAbilityGoalData.overrideGoalData, DefaultAbilityGoalData.modifyGoalData)
	Ai:Print("===============================================")
end

--? @shortdesc Set modify goal data for ability goals.  modifyGoalData is cloned; values specified via keyname_Multiplier are used for the numeric keyname encounter ability goal value.
--? @args Table modifyGoalData
function AIAbilityGoal_SetModifyGoalData(modifyGoalData)
	Ai:Print("===============================================")
	Ai:Print("Setting AbilityGoal modify data...")

	local DefaultAbilityGoalData = Ai.goals.DefaultAbilityGoalData
	DefaultAbilityGoalData.modifyGoalData = Clone(modifyGoalData) 

	DebugPrintGoals(DefaultAbilityGoalData.defaultGoalData, DefaultAbilityGoalData.overrideGoalData, DefaultAbilityGoalData.modifyGoalData)
	Ai:Print("===============================================")
end


